#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/xj.deng/development/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/xj.deng/alibaba/xj_fluttergo/flutter-go"
export "FLUTTER_TARGET=lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "SYMROOT=${SOURCE_ROOT}/../build/ios"
export "FLUTTER_FRAMEWORK_DIR=/Users/xj.deng/development/flutter/bin/cache/artifacts/engine/ios-release"
export "FLUTTER_BUILD_NAME=1.0.6"
export "FLUTTER_BUILD_NUMBER=1.0.6"
