#待加入的组件

以下是flutter go 中缺失的部分组件. 欢迎大家共建.参与方式请看[共建说明](https://github.com/alibaba/flutter-go/blob/master/docs/contribute.md)
<h6>注：✔表明已加入</h6>

- [x] Scaffold
- [ ] Hero
- [ ] Listener
- [ ] Safearea
- [ ] ClipRect
- [ ] WillPopScope
- [ ] FutureBuilder
- [ ] StreamBuilder
- [ ] Notification
- [ ] runZoned
- [ ] IgnorePointer
- [ ] AbsorbPointer
- [ ] FlutterLogo
- [ ] Placeholder
- [ ] Offstage
- [ ] Visibility
- [ ] Baseline
- [ ] CustomPainter
- [ ] Border
- [ ] Wrap
- [ ] Transform
- [ ] SingleChildScrollView
- [ ] Positioned
- [ ] InheritedWidget
- [ ] PageView
- [ ] LayoutBuilder
- [ ] MediaQuery
- [ ] RefreshIndicator
- [ ] Opacity
- [ ] ExcludeSemantics
- [ ] DataTable
- [ ] Tooltip
- [ ] Form
- [ ] FormField