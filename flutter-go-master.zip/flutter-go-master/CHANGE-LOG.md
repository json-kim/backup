## 更新日志

#### 8/28/2019
  - [x] Modify: IsOpen 的移步判断
  - [x] Update index.md
  - [x] Update index.dart
#### 5/28/2019
  - [x] change:async master
  - [x] modfiy:应用商店
  - [x] Merge pull request #222 from DeckeDeng/develop
  - [x] add home scaffold
#### 8/22/2019
  - [x] Merge pull request #322 from alibaba/beta
  - [x] Modify: web view 方法回退
  - [x] Merge pull request #321 from alibaba/beta
  - [x] Merge pull request #317 from alibaba/beta
  - [x] Merge branch 'master' into beta
  - [x] Update contribute.md
#### 8/12/2019
  - [x] update: doc & tpl
  - [x] Update tpl.md
  - [x] Merge pull request #313 from Nealyang/beta
  - [x] 添加登陆错误提醒
#### 3/11/2019
  - [x] Update README-en.md
#### 8/15/2019
  - [x] update: router path
  - [x] ci
  - [x] update: view remote code
  - [x] 整理文件
#### 8/13/2019
  - [x] Modify
  - [x] Modfiy:
  - [x] update: page issue template
#### 8/1/2019
  - [x] merge code
#### 7/29/2019
  - [x] Merge branch 'master' of github.com:alibaba/flutter-go into beta
  - [x] delete .github no use file
  - [x] docs(update: pr template):
  - [x] del: no use file
  - [x] Merge branch 'master' of github.com:alibaba/flutter-go
  - [x] docs(add widget about issue):
  - [x] Merge branch 'temp' into beta
  - [x] 迁移位置
  - [x] update: template
  - [x] update: 处理合并导致的总理2
#### 8/7/2019
  - [x] fix bug
  - [x] Merge pull request #302 from Nealyang/beta
  - [x] remove get collection
  - [x] tep
  - [x] update: 完成markdown动态更新
#### 8/8/2019
  - [x] remove user appBar
  - [x] bottomBar 添加个人中心
  - [x] Merge pull request #309 from DeckeDeng/beta2
  - [x] ios project.pbxproj
  - [x] Merge pull request #308 from DeckeDeng/beta2
  - [x] Merge pull request #304 from Nealyang/beta
  - [x] 修改 ios 配置文件
  - [x] update: 临时增加code-review页
#### 6/28/2019
  - [x] Merge pull request #264 from DeckeDeng/beta2
  - [x] Merge pull request #263 from DeckeDeng/beta2
  - [x] Merge branch 'beta' into beta2
  - [x] 消息反馈页面
#### 2/1/2019
  - [x] Merge branch 'develop' of https://github.com/alibaba/flutter-go into develop
  - [x] feat:android splash
  - [x] feat:add android splash
  - [x] Merge pull request #116 from hanxu317317/develop
  - [x] docs(更新Readme中环境信息):
  - [x] Merge pull request #115 from hanxu317317/develop
  - [x] feat(首页欢迎图, 加入第一次访问判断.):
  - [x] Merge branch 'develop' into sptil
  - [x] update: ios启动图描述
  - [x] fix:yaml
  - [x] fix:
  - [x] Merge pull request #113 from hanxu317317/develop
  - [x] fix:mtl buidl apk test
  - [x] refactor(conflict):
  - [x] add sp
  - [x] fix(解决由于flutter 版本问题导致的报错):
  - [x] fix:back
  - [x] fix:package err
  - [x] fix:modify github package name fail and test
  - [x] fix:build before modify package's name
#### 7/12/2019
  - [x] Merge pull request #279 from Nealyang/beta
  - [x] add
  - [x] d
#### 8/6/2019
  - [x] issuse message
  - [x] Merge pull request #294 from Nealyang/beta
  - [x] 修改为线上地址
  - [x] 个人中心、收藏、搜索
#### 7/25/2019
  - [x] Merge branch 'beta' of github.com:alibaba/flutter-go
#### 7/23/2019
  - [x] zefyr
#### 7/22/2019
  - [x] feature:个人设置
#### 7/15/2019
  - [x] appstore 反馈错误
  - [x] readme错误
  - [x] 标题错误，跳转错误
#### 7/11/2019
  - [x] update: 迁移新老数据结构与收藏
  - [x] update: 增加环境配置. 挂载在application静态属性上
  - [x] update: 修改文章
#### 4/8/2019
  - [x] flutter project switch ios or android by androidstudio
  - [x] android permission
  - [x] remove extra files
#### 6/18/2019
  - [x] 推送，ios/android,test
#### 6/15/2019
  - [x] 删除node相关
  - [x] Merge branch 'develop' of github.com:alibaba/flutter-common-widgets-app into web
  - [x] update: 完善demo
  - [x] update: 界面增加title属性
  - [x] add: cli使用说明
#### 6/11/2019
  - [x] update: 替换markdown包引入方式
  - [x] add: 加入标准page模板
  - [x] 加入标准page
  - [x] 加入初始化demo
  - [x] 引入三方flutter_markdown gi
#### 6/10/2019
  - [x] Merge pull request #249 from Nealyang/beta
  - [x] 添加收藏功能
  - [x] update: 标准化代码.
  - [x] goCli 完成90%
#### 6/4/2019
  - [x] markdown
  - [x] 加入初始gocli
  - [x] add page demo
  - [x] 增加page的统一入口
  - [x] add demos packges
  - [x] Merge pull request #240 from Nealyang/beta
  - [x] 退出登陆、feedback 测试
#### 5/31/2019
  - [x] 添加个人中心
#### 5/30/2019
  - [x] 首页不刷新
  - [x] Merge pull request #1 from forever-713/zuston-patch-1
  - [x] Fix App name error
#### 5/29/2019
  - [x] 添加 github oAuth 认证，添加错误提醒
#### 5/23/2019
  - [x] readme.md
  - [x] Merge pull request #219 from weikx/develop
  - [x] Merge pull request #215 from DeckeDeng/develop
  - [x] delete firstPage
  - [x] de
  - [x] Test：测试分支
  - [x] Merge branch 'develop' of https://github.com/weikx/flutter-go into develop
  - [x] Change word 'Free' into 'Three'
  - [x] Chang word 'Free' into 'Three'
#### 5/17/2019
  - [x] Merge pull request #216 from alibaba/master
#### 5/14/2019
  - [x] update version
#### 2/3/2019
  - [x] fix(解决ios报错):
  - [x] Merge pull request #119 from Nealyang/master
  - [x] fix:fix code conflic
  - [x] fix: code conflict
  - [x] Merge branch 'develop' into master
  - [x] fix:view code
  - [x] Merge pull request #118 from alibaba/dev/yisheng
#### 5/9/2019
  - [x] test version
#### 5/7/2019
  - [x] merge origin
  - [x] add update test
  - [x] Merge branch 'develop' of github.com:alibaba/flutter-go
  - [x] cookie 校验
  - [x] modify home.dart bottom tab
  - [x] session 验证
  - [x] merge develop
  - [x] 登陆
  - [x] Merge pull request #205 from alibaba/dev/sanl
  - [x] modify bottom tab
  - [x] delete ios file
  - [x] add apk
  - [x] Login 登陆界面
#### 5/6/2019
  - [x] add login
#### 5/1/2019
  - [x] Modfiy： 改造业内资讯页面
#### 4/30/2019
  - [x] Add:二期开发-重构首页布局
  - [x] gradle 4.10.2 包添加AndroidX配置
#### 2/19/2019
  - [x] packagename
  - [x] Merge pull request #148 from alibaba/dev/yisheng
  - [x] refactor:按照代码规范调整import 文件
  - [x] update: 规范
  - [x] Merge pull request #147 from Nealyang/master
  - [x] fix:修复TabBar demo
  - [x] Merge pull request #146 from Nealyang/master
  - [x] refactor: 根据规范重构代码
  - [x] Merge pull request #145 from alibaba/dev/yisheng
  - [x] refactor:按照代码规范调整markdow解析
  - [x] refactor(规范化代码):
  - [x] Merge pull request #143 from Nealyang/master
  - [x] refactor:按规范修改代码、注释等
  - [x] Merge pull request #142 from Nealyang/master
  - [x] commit
  - [x] Merge pull request #141 from Nealyang/master
  - [x] Merge pull request #140 from Nealyang/master
  - [x] Merge pull request #135 from hanxu317317/develop
  - [x] Merge branch 'develop' into develop
  - [x] Merge pull request #139 from Nealyang/master
  - [x] Merge branch 'develop' of github.com:alibaba/flutter-common-widgets-app
  - [x] refactor:根据规范，重构代码
  - [x] modify code comments
  - [x] Merge pull request #138 from alibaba/dev/yisheng
  - [x] refactor:按照代码规范调整注释文件
#### 4/29/2019
  - [x] test app store
  - [x] Merge branch 'master' into dev/sanl
  - [x] 修改bug
#### 4/26/2019
  - [x] Debug: GoogleService-Info.plist 位置问题 导致错误
  - [x] change LICENSE date
  - [x] 变更许可
  - [x] Merge pull request #189 from alibaba/develop
  - [x] change License
#### 4/22/2019
  - [x] release apk
  - [x] Merge pull request #192 from alibaba/dev/yisheng
  - [x] 格式化
  - [x] Merge pull request #191 from alibaba/dev/yisheng
  - [x] Delete:删除 .gradle 文件夹
  - [x] Merge pull request #188 from alibaba/dev/yisheng
#### 4/17/2019
  - [x] gridView 网格效果 图片流
  - [x] 添加渐变效果/网络图片覆盖图层渲染/图片填充
#### 1/31/2019
  - [x] Merge pull request #112 from alibaba/dev/yisheng
  - [x] Debug:canvas 路由问题
  - [x] Merge pull request #111 from alibaba/dev/yisheng
  - [x] feat: Canvas 细化各种方法
  - [x] add file
  - [x] fix:code
  - [x] feat(加入启动图, 时间2秒):
#### 4/12/2019
  - [x] update: 修改错字
  - [x] Merge pull request #180 from alibaba/develop
  - [x] add: doc roadmap
#### 4/1/2019
  - [x] remove recruit
  - [x] move recruit
#### 3/31/2019
  - [x] 增加模板
  - [x] Create pull_request_template.md
  - [x] Delete .github
  - [x] Create .github
  - [x] Merge pull request #173 from alibaba/master
#### 2/2/2019
  - [x] fix: 部分代码添加 mounted
  - [x] Merge pull request #117 from alibaba/dev/yisheng
  - [x] fix:修复Canvas组件收藏的bug
#### 2/20/2019
  - [x] 同步文件
  - [x] Merge pull request #152 from hanxu317317/develop
  - [x] 更新跳转页方式
  - [x] modify logo
  - [x] Merge pull request #149 from hanxu317317/develop
  - [x] fix(解决返回首页报错的问题):
#### 2/11/2019
  - [x] fix: 部分代码 analysis 解决
#### 2019-2-5
- [x] 处理因为flutter版本导致的项目运行不起来
- [x] 更新readme, 加入开发日志, 与相关说明
- [x] 加入 首页欢迎效果图
- [x] refactor(整理richText的说明):
- [x] 解决一些页面的code演示打不开的问题
- [x] add:开发规范
- [x] add:版本更新历史链接
- [x] Update README.md
- [x] add:添加版本号
- [x] feat:添加代码开发规范
- [x] refactor(update: version & fiexed warns):
- [x] fix(solve conflict):
- [x] modify:toast and andrid apk label
- [x] Add:自动 pr 工具抓取器，抓取两周前至今的,提交数据，并去重
- [x] fix:fluttetToast backHome
- [x] fix:modified the style of toast && remote files
- [x] chore(删除tools/log.json):
- [x] 重构文件结构
- [x] 关于手册图标更换
- [x] 增加demo: CupertinoNavigationBar CupertinoPageRoute CupertinoPageScaffold CupertinoPicker，CupertinoPopupSurface CupertinoTimerPickerDemo


#### 2019-1-24
- [x] 功能：更新小部件的图标
- [x] 功能：添加CupertinoTimerPickerDemo
- [x] 调试：消除警告
- [x] 修复：关于手册图标更换
- [x] 添加：文案描述
- [x] 添加：CupertinoPicker，CupertinoPopupSurface
#### 2019-1-23
- [x] 修复: 导航栏home返回报错
- [x] 修复：收集错误
- [x] 添加：CupertinoNavigationBar CupertinoPageRoute CupertinoPageScaffold
#### 2019-1-22
- [x] 功能：在Allsimon拉请求中添加英文简介
#### 2019-1-21
- [x] 功能：Cupertino的子项
#### 2019-1-20
- [x] 功能：CupertinoSwitch演示
- [x] 功能：为搜索列表加入图标
- [x] 功能：CupertinoSliverRefreshControl演示
- [x] 功能：CupertinoSliverNavigationBar演示
#### 2019-1-18
- [x] 更新：SharedPreferences保存数据和android设备布局溢出
- [x] 功能：添加CupertinoScrollbar演示
- [x] 功能：第四页暂时用欢迎页替代。后期再开发
#### 2019-1-17
- [x] 添加：+许可证
#### 2019-1-16
- [x] 转换：将README翻译为En语言环境
- [x] 功能：CupertinoScrollbar演示
#### 2019-1-14
- [x] 添加：增加手册页面
- [x] 功能：文字演示
- [x] 重构：修改过的图标
- [x] 重构：文档，文章，组件收藏，新增webView
- [x] 重构：修改过的演示
- [x] 重构：代码视图
- [x] 更新：版本 和readme.md
- [x] 修改：添加代码视图
- [x] 功能：添加搜索历史记录板
- [x] 修改：列出加标头错误
#### 2019-1-15
- [x] 功能：welcomepage
#### 2019-1-13
- [x] 添加：一些输入描述
- [x] 功能：加入GridPaper＆SliverGrid
- [x] 重构：修改db
- [x] 重构：删除数据库 TabBarView
- [x] 添加：网格视图
- [x] 修改：checkbosListTile 错误
- [x] 修改：自动提示文案
- [x] 功能：增加免责声明，声明组件，自动弹出，左上角入口
- [x] 重构：整理数据库初始逻辑，判断数据库完整性，判断是否存在已知的cat，widget，collection 三张表。
- [x] 修复：DialogDemo，无法关闭的问题
#### 2019-1-12
- [x] 修复：icon没有，但内容有的，组件，给补充了icon
- [x] 修改：1.整理文件 2.修正分析
- [x] 更新：flutter_rookie_book => flutter_go
- [x] 更新：更新SearchInput文件名=> search_input
- [x] 修改：文件名称的大小写规范
- [x] 修改：修正bottomNavigationBar iconButton警告
