# FlutterGo

感谢大家一直以来对 FlutterGo 的支持与反馈。



但是 **由于团队内部组织调整变更**，很遗憾的宣布 FlutterGo 目前**暂停维护**。



但是后期我们会再升级迭代 FlutterGo 新版本，也同时希望更多Flutter爱好者参与加入。



- 简历投递 邮箱：yifeng.yl@alibaba-inc.com
- 钉钉扫码直接连接:
- <img src="https://gw.alicdn.com/tfs/TB1VXgXYFT7gK0jSZFpXXaTkpXa-716-914.png" width=278 height=357>
