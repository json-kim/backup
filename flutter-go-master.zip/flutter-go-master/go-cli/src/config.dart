// 生成Demo的目录位置
const TARGET_PAGE_DIC = 'lib/standard_pages';
const TARGET_DEMO_DIC = 'lib/page_demo_package';

