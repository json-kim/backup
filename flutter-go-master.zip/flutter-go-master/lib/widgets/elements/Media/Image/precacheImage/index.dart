/// @Author: 一凨
/// @Date: 2018-11-16 15:09:12
/// @Last Modified by:   一凨
/// @Last Modified time: 2018-11-16 15:09:12

import 'package:flutter/material.dart';

class Demo extends StatefulWidget {
  static const String routeName = '/element/Media/Image/precacheImage';
  _DemoState createState() => _DemoState();
}

class _DemoState extends State<Demo> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: null,
    );
  }
}
