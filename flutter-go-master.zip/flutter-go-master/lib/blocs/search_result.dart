///
/// Created with Android Studio.
/// User: 一晟
/// Date: 2019/4/28
/// Time: 7:11 PM
/// email: zhu.yan@alibaba-inc.com
/// tartget:
///
class SearchResult {
  String title;
  String source;

  SearchResult({this.title, this.source});
}
