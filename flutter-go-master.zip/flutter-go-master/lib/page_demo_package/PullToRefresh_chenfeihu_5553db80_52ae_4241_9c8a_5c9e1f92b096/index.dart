//
// Created with flutter go cli
// User: chenfeihu
// Time: 2019-09-24 12:11:14.085126
// email: 763551832@qq.com
// desc:  刷新组件
//

import 'src/index.dart';

var demoWidgets = [new Demo()];
