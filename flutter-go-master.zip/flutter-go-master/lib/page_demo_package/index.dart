import 'PullToRefresh_chenfeihu_5553db80_52ae_4241_9c8a_5c9e1f92b096/index.dart'
    as StandardDemo_PullToRefresh_5553db80_52ae_4241_9c8a_5c9e1f92b096;
import 'RangeSlider_RangeSlider_e5f958bc_52ae_4241_9c8a_5c9e1f92b096/index.dart'
    as StandardDemo_RangeSlider_e5f958bc_52ae_4241_9c8a_5c9e1f92b096;
import 'demoName_yourName_1a29aa8e_32ae_4241_9c8a_5c9e1f92b096/index.dart'
    as StandardDemo_demoName_1a29aa8e_32ae_4241_9c8a_5c9e1f92b096;
import 'local_ab_2c1d57d0_42ae_4241_9c8a_5c9e1f92b096/index.dart'
    as StandardDemo_local_2c1d57d0_42ae_4241_9c8a_5c9e1f92b096;

var demoObjects = {
  '5553db80_52ae_4241_9c8a_5c9e1f92b096':
      StandardDemo_PullToRefresh_5553db80_52ae_4241_9c8a_5c9e1f92b096
          .demoWidgets,
  'e5f958bc_52ae_4241_9c8a_5c9e1f92b096':
      StandardDemo_RangeSlider_e5f958bc_52ae_4241_9c8a_5c9e1f92b096.demoWidgets,
  '1a29aa8e_32ae_4241_9c8a_5c9e1f92b096':
      StandardDemo_demoName_1a29aa8e_32ae_4241_9c8a_5c9e1f92b096.demoWidgets,
  '2c1d57d0_42ae_4241_9c8a_5c9e1f92b096':
      StandardDemo_local_2c1d57d0_42ae_4241_9c8a_5c9e1f92b096.demoWidgets
};
