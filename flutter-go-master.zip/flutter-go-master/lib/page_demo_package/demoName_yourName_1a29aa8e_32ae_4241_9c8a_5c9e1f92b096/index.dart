//
// Created with flutter go cli
// User: yourName
// Time: 2019-06-10 20:37:27.289097
// email: yourEmail
// desc:  这是一个测试的标准demo
//

import 'src/index.dart';

var demoWidgets = [new Demo()];
