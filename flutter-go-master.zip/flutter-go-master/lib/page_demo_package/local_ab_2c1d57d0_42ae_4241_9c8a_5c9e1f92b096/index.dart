//
// Created with flutter go cli
// User: ab
// Time: 2019-08-06 17:26:02.905889
// email: email
// desc:  ags
//

import 'src/index.dart';

var demoWidgets = [new Demo()];
