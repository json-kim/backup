# 目录说明

本目录文件结构与文件命名, 使用cli进行更新


# demos 目录文件结构

```
demos
├── ${demoName}-${author}-${32位demoID}
│   ├── index.dart
│   └── src
│       ├── .demo.json
│       └── ${demoName}.dart
├── ...${demoName}-${author}-${32位demoID}
├── index.dart
├── info.json
└── readme.md
```
    