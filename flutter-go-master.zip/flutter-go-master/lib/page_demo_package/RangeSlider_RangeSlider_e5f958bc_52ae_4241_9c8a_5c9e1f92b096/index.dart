//
// Created with flutter go cli
// User: RangeSlider
// Time: 2019-09-12 15:11:05.512158
// email: hanxu317@qq.com
// desc:  RangeSlider widget demo
//

import 'src/index.dart';

var demoWidgets = [new Demo()];
